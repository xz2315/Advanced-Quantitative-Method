### Gov 1002/2001/Stat E200
### Introduction to R
### Mayya Komisarchik, Anton Strezhnev

### Much of this material comes from the R tutorial 
### by Stephen Pettigrew - found at www.stephenpettigrew.com

#############################################################
## Downloading and installing R
#############################################################

## Download R Here: 
  ## http://cran.r-project.org/mirrors.html

## Download RStudio Here: 
  ## http://www.rstudio.com/ide/download/desktop
  ## RStudio is a useful integrated development environment   
  ## (IDE) for R.
  
## MAKE SURE YOU INSTALL R BEFORE YOU INSTALL RSTUDIO!!!

#############################################################
## PREAMBLE: Script and Console
#############################################################

## How do I use R once I've downloaded it?
  ## If you've opened R by itself:
    ## You can just type your code to the right of the ">" 
    ## symbol you see on your screen and press enter to 
    ## execute it.
    
    ## If you want to save your code, you can type multiple 
    ## lines of code in any word processing software and
    ## save that as a document. 
    
      ## Then, to run your code, just copy and paste each 
      ## line (or series of lines) that you want R to run 
      ## into your console.

  ## If you are in RStudio:
    ## You can send your code directly to R by typing next 
    ## to the ">" symbol in your console (usually the 
    ## bottom window)

    ## If you want to save your code, type it into the editor 
    ## window above your console. This part of RStudio is 
    ## your word processor. If you hit file and save, or 
    ## the disc icon at the top left, RStudio will 
    ## save your script (just what you've written in the
    ## top panel) as an R "script" with a .R file extension.

    ## You can run the code in your editor window by 
    ## highlighting (or starting your cursor in front of) 
    ## the line or lines of code you want to run, then 
    ## hitting "control + enter" (PC) or 
    ## "command + return" (MAC)

## REGARDLESS OF HOW YOU CHOOSE TO WRITE YOUR CODE, YOU 
## SHOULD ALMOST ALWAYS SAVE YOUR SCRIPT AS A .R FILE!!! 
  ## R does not save a complete history of your 
  ## commands into a script file by default!

## Adding comments to your code:
  ## It's good practice to comment everything in 
  ## your code so that you can come back to it 
  ## later and remember what you were doing!

  ## Every line that begins with '#' is a comment, 
  ## and therefore ignored by the console. 
  ## R doesn't "execute" these lines.
  
  ## You can add comments as separate lines or after
  ## (but not before) a line of executable code.

#############################################################
## Installing Packages
#############################################################

## Packages are software that extend R's functionality.
## You can install a package by typing the command:
  ## install.packages("name.of.package.in.quotes")

## There are many packages in R that you will want to use
## throughout this and other courses.

## Let's start by installing a package that you will need
## to import data in other formats into R

  install.packages("foreign")

  ## Note that you can install multiple packages in one line
  ## line of code, like this:

    ## install.packages(c("xtable", "stargazer", "gam"))

## You will only need to install your package once unless
## you upgrade your version of R or reinstall it.

## If you are in RStudio, you can see the list of packages
## you have installed by selecting the Packages tab. 

## It's a good idea to update those periodically by 
## selecting a series of packages and hitting
## the Update button in RStudio or by typing 
## update.packages("name.of.package.in.quotes")

## YOU DO NEED TO TELL R THAT YOU PLAN TO USE A PACKAGE
## EVERY TIME YOU USE IT
  ## You can do that by specifying:
  ## library(name.of.package.noquotes)
  ## or require(name.of.package.noquotes)

## Use one of those commands to call the package you
## need EVERY TIME you plan to run it (once per script)

  require(foreign)

#############################################################
## Working Directories
#############################################################

## A working directory is the full location of the folder 
## or file that you are working in. 

## PC users can typically see this displayed at the top of 
## their explorer window, it looks something like:
## "C:/Documents and Settings/Your name/"

## Mac users can retrieve the full directory path they want 
## by right-clicking on the object or folder they are 
## interested in, selecting "Get Info", and copying the 
## line that shows up in the "Where:" section of the new
## window that opens.

## You can check the working directory you are currently in 
## by typing:

  getwd() # R will print your current directory

## You can change the working directory in R by using the 
## setwd() command:

  setwd("~/Dropbox/Teaching/Course Folders/Gov 2001/Gov2001 2014/Spring2016/Sections/Section 0 R Intro/")

  ## Note that in most systems ~ gives you your home
  ## directory (C:/Users/yourname/)

  ## IF YOU WANT TO LOAD A SPECIFIC FILE, MAKE SURE YOU 
  ## SET YOUR WORKING DIRECTORY TO THE LOWEST-LEVEL FOLDER 
  ## THAT CONTAINS THAT FILE!

  ## Do NOT set your working directory to the file itself, 
  ## the last level should be a folder

  ## Also, do NOT set your working directory to a higher 
  ## level folder. For instance, in the path above,
  ## just stopping at Dropbox will not work since there 
  ## will not be a data file by the name I'm looking for
  ## in the top level of my Dropbox directory.

## You can opt do this interactively instead of typing or
## copying your directory path:

  setwd(dirname(file.choose()))

  ## If you choose this option, you should manually
  ## select THE FILE corresponding to the data you want
  ## to use, NOT THE FOLDER.

#############################################################
## Basic operations
#############################################################

## R performs basic operations just like your calculator:

  2 + 2 ## addition

  9 - 4 ## subtraction

  6 * 12 ## multiplication

  2 ^ 8 ## exponentiation

  86 / 4 ## division

  log(12) ## the log function in R is base e, 
          ## or the "natural log"

  exp(2) ## equivalent to 2.71828^2 or e squared
  
  ## R preserves order of operations:
  
    ## Example: exponentiation before division

      2 / 9 ^ 2 == 2 / 81 

      2 / 9 ^ 2 == (2/9) ^ 2
      
#############################################################
## Getting Help in R
#############################################################

## You can search R's extensive documentation if you are not 
## sure about which commands might help you do certain tasks:      

  ## If you know the keyword for the function or topic 
  ## you're interested in, but NOT the specific function in
  ## R, use a double question mark to search:
      
    ??"mean"
      
      ## Notice that, if you are in RStudio, you can go to 
      ## your Help tab and search there too
  
  ## If you already know the name of the function you want to 
  ## learn more about, you can look it up using a single 
  ## question mark:
    
    ?mean

## The internet also has a large collection of helpful R 
## resources. Here are two of the most useful ones:

## Stack Overflow http://stackoverflow.com/questions/tagged/r
## Cross Validated http://stats.stackexchange.com/questions/tagged/r
## Quick R http://www.statmethods.net/

  ## PRO TIP: GOOGLE YOUR ERRORS. LITERALLY. COPY AND 
  ## PASTE YOUR ERROR MESSAGES INTO GOOGLE! You'll 
  ## typically see results discussing what causes the type of 
  ## error you are getting and how to fix it!
      
#############################################################
## Objects in R
#############################################################

## Variables are stored in R's active memory or "workspace."
      
    ## If you're using RStudio, you can see what's in your 
    ## workspace on the top right.
    
    ## If not, you can use the ls() function to get a list 
    ## of everything in the workspace.
      
        ls()
      
## You can create objects in R by
      ## (1) Choosing names for your objects
      ## (2) Assigning valus to those objects by using 
          ## an assignment operator
      
          ## R uses several assignment operators. 
          ## The most common is the "<-" operator, but you 
          ## will also occasionally see
          ## "=", <<-", "->" ,  and "->>". 
      
          ## The important thing to remember is that all of 
          ## these operators just connect the two values 
          ## on either side of them to one another.
      
      ## Here are some examples of assignments in R
        number_one <- 1 ## Here, we've created an integer 
                        ## object number_one and stored 
                        ## a 1 in it
        number_one # We can now access that object by its name
        
        ## Object names can be anything that starts 
        ## with a character (a-z or A-Z): 
        ## asfeji32 is a valid object name, 483ljsd is not
        ## Name your objects in ways that help you read the 
        ## code better:
        ## mean_gdp is a better object name than variable1 
        
  ## Single element objects - integers, numeric ("real numbers"),
  ## strings, logical
  #############################################################
    
    integer_obj <- 4 ## Integer
    numeric_obj <- 4.39053 ## Numeric
    string_obj <- "This is a string" ## Strings are denoted by 
                                     ## double quotes or single 
                                     ## quotes
    logical_obj <- TRUE ## Logicals are either 
                        ## TRUE or FALSE (T/F)
  
  ## Multi-element objects - vectors, matrices, arrays, 
  ## lists and data frames
  #############################################################
    ## Vectors
    
    ## Use the c() function to concatenate a bunch of single 
    ## elements of the same type. Separate elements by commas
    
    vector_of_integers <- c(3, 9, 10, 4) 
    vector_of_integers
    
    ## Or use the "rep" function to repeat an element some 
    ## number of times - this code repeats the number 
    ## 4.39024 10 times
    
    vector_of_numerics <- rep(4.39024, 10)
    vector_of_numerics
    
    ## Or use the colon or sequence syntax to generate 
    ## vectors that are sequences of numbers:
    
    sequentialvec <- 1:10
    backwardssequence <- 10:1
    seqvec2 <- seq(0, 50, 10) 
    
    sequentialvec  
    backwardssequence
    seqvec2
    
      ## The syntax for seq is seq(from, to, by)
    
    ## You can do standard operations on vectors
      
      vector_of_integers - 2 * vector_of_integers 
    
    # You can select an element of a vector using brackets
      
      vector_of_integers
      vector_of_integers[1] 
    
    # You can select multiple elements using a numeric vector
      
      vector_of_numerics
      vector_of_numerics[2:4] 
    
    ## Note that we can assign output from functions to new elements
    ## - for example, storing the mean
      
      mean_of_vector_of_numerics <- mean(vector_of_numerics)
      mean_of_vector_of_numerics
      
      ########################################################
      ########################################################
      ### Work Break
      ########################################################
      ########################################################
      
      
      # Create a vector containing all of the integers from 100 
      # to 200 and store it to an object named "seq12"
      
      # Then store the mean of that vector to an object named mean12
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      seq12 <- seq(100,200,1)
      seq12
      mean12 <- mean(seq12)
      mean12
      
      
    ## Matrices
    ## Two-dimensional row-by-column object 
      ## Hint: It's row by column (not column by row)
      ## because it's remote controlled (RC) cars, RC Cola,
      ## and Ray Charles
      
      ## Because if you make your matrix with
      ## dimension Charles Ray, you'll be doing 
      ## statistics blindly
      
    ## (can be composed of integers, numerics and strings)
      
      ## Use the matrix function to create a matrix - 
      ## R fills the matrix column by column
      
      vector_of_integers
      two_by_two_matrix <- matrix(vector_of_integers, nrow=2, ncol=2) 
      two_by_two_matrix
      
      ## You can add matrices with same dimensions
        
        two_by_two_matrix + two_by_two_matrix 
      
      ## * indicates element-wise multiplication - 
      ## if you want to do matrix multiplication you need to use
      ## the %*% operator
    
          two_by_two_matrix * two_by_two_matrix
          
          ## Matrix multiplication
          
          two_by_two_matrix %*% two_by_two_matrix 
      
      ## You can select matrix elements use brackets [rows, column]
        
          two_by_two_matrix[1,2] 
      
      ## You can also use vectors to select multiple elements
      ## Since a matrix is a 2 - dimensional r x c object,
      ## leaving the first element blank tells R you don't want
      ## any specific rows. Leaving the second element blank
      ## would similarly pull a whole row but no specific columns
      
        two_by_two_matrix[,2] 
        two_by_two_matrix[,1]
        
########################################################
### Boolean operations
########################################################
  ## Boolean operations evaluate relationships between
  ## terms
      
  ## Simple boolean operations (TRUE/FALSE)
    
    2 == 2 ## Equality - note, that == denotes the 
           ## boolean  operator, = is for assignment
           ## or for function arguments) - returns TRUE
    
    2 != 2 ## Inequality - !=
    
    4 > 2 ## Greater than
    
    4 >= 2 ## Greater than or equal to
    
    2 < 4 ## Less than
    
    2 <= 4 ## Less than or equal to
    
    ## Note that ! generally means "NOT"
    
    !(4 > 2) # Returns FALSE
    
    ## So, for more complex operations,
    ## you can wrap your whole statement
    ## in parenthesis and put a ! in front
    ## to indicate "the opposite of"
      
      full <- state.name ## R has built in state names!
      full
      
      ## U.S. Census - designated Pacific States:
      
        pacstates <- c("Washington", "Oregon", 
                       "California", "Alaska", "Hawaii")
      
        !(full %in% pacstates)
        
        ## Shows you which of the full 50 states ARE NOT 
        ## pacific states!
        
        ## Can see this more directly by using that
        ## command to subset:
          
          full[!(full %in% pacstates)]
      
    ## You can use booleans on vectors
          
      c(3,5,2,0,-4,-5) > 0
    
    ## You can combine boolean operations using 
    ## & - AND 
    
      2==2 & 4==2 # Returns FALSE (BOTH)
    
    ## | - OR
      
      2==2 | 4==2 # Returns TRUE (EITHER)
      
    ## xor() - "Exclusive OR" - Returns TRUE if 
    ## one or the other element is TRUE but not
    ## if both are TRUE
    
      xor(2==2, 4==2) # Returns TRUE
      
      xor(3==3, 6==6) # Returns FALSE
    
########################################################
## Functions
########################################################

    ## Using functions    
    ########################################################
    ## Functions are operations more complex than your basic
    ## math operations +, -, *, /, ^, etc.
    
    ## We've already seen some of R's basic functions, such
    ## as mean(), log(), and c()
    
    ## But there are many more built in functions in R!
    ## Search for these using your ? and ?? tools!
    
    ## In addition, you can write your own functions in R
    ## very easily!
    
    ## The general syntax TO USE function in R is:
    ## function.name(arguments)
    ## where the function name varies according to 
    ## what the function is, and your arguments
    ## contain values for:
    ## The object to which you want to apply
    ## your function. In many cases,
    ## you can create the object right inside
    ## your function statement.
    
    ## Various options that you can use
    ## to make your function work in different
    ## ways.
    
    ## Examples:
    mean(c(2,3,10,3,NA), na.rm = TRUE) 
    
    ## This code applies the mean function
    ## to the object c(2,3,10,3,"NA"), which
    ## is a vector that we are creating
    ## right inside the function.
    
    ## na.rm is an option available in the
    ## mean function (and many others) that
    ## tells R to ignore NAs
    ## (ONLY true for NA, not "NA")
    
    ## Functions take arguments in order, or you 
    ## can specify them using the "=" sign
    mean(x = c(2,3,10,3)) # mean takes one argument, x
    
      
    ## Defining your own functions
    ########################################################
    
    ## The general syntax for BUILDING YOUR OWN function
    ## in R is:
    ## name.of.function <- function(inputs){
    ## some arguments (what you want to do with the
    ## inputs)
    ## return(what you want your function to show
    ## as the output)
    ##}
    
    ## Suppose we wanted to write a function that added 2
    ## to every element in some input x:
    
    add_2 <- function(x){ # function commands are in the 
      #brackets and separated by lines
      k <- x + 2 # add 2
      return(k) # return the k variable
    }
    
    ## Notice that there is no "k" variable
    ## stored in your environment! 
    
    ## Store function output using the 
    ## assignment operator "<-"
    
    adding_2_to_6 <- add_2(6)
    
    adding_2_to_6
    
    ########################################################
    ########################################################
    ### Work Break
    ########################################################
    ########################################################
    
    ## Write a function that takes a vector of numbers and returns the 
    ## cube root divided by the natural log of each number in the vector
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    example <- function(x){
      return(x^(1/3) / log(x))
    }
    
    example(5:10)
  
########################################################
## Conditional Statements
########################################################
# What are the reasons we check to see whether data 
# values meet certain conditions?
  # One reason may be that we want to subset our data 
  # to a portion we are interested in, so our
  # conditional statements reflect the portion 
  # we're interested in.
    
  # Another reason may be that we only want to perform 
  # operations on only certain observations. 
  # Further, we may be doing a repetitive operation, so 
  # we'll want R to automatically identify the data 
  # that's important enough and just apply the operation to 
  # the data we want it done to.
  # To do that, we can use an if statement. 
  
  #An 'if' statement takes the form:
    
  # if(logical boolean){function to perform if the boolean is TRUE}
  # For example:
  
    x <- 1000000
    
    if(x > 10000){
      "x is a really big number"
    }
    
    if(x < 10000){
      "x isn't that big"
    }
    
    # Why doesn't the second statement print anything?
    # Since we set x to 100000000, x < 10000 evaluates to FALSE
    
    # What if we actually want to see R perform an 
    # action when our if statement evaluates to false?
      
    # We can use else statements to deal with instances 
    # where the boolean evaluates to FALSE
    
    # Note that using multiple if/else statements 
    # requires that you wrap the whole thing
    # in curly brackets, { }:
    
    x <- 1
    
    if(x > 10000){
      "x is a really big number"
    }  else{
      "x isn't that big"
    }
    
    # The ifelse() function can be used instead of 
    # 'if' and 'else' separately. The syntax for
    # ifelse() is ifelse(boolean statement, value if true, value if false):
    
    ifelse(x > 10000,
           "x is a really big number",
           "x isn't that big")
    
    
    # You can include multiple conditions in a conditional
    # statement. This is how you can do it with separate
    # if and else statements:
    
    y <- "Math!"
    
    if(!is.numeric(y)) {
      "y isn't even a number"
    } else if(y == 10000){
      "y equals 10000"
    } else if(y > 10000){
      "y is really big"
    }  else{
      "y isn't that big"
    }
    
    # You can also code that using ifelse:
    
    ifelse(!is.numeric(y),
           "y isn't even a number",
           ifelse(y == 10000,
                  "y equals 10000",
                  ifelse(y > 10000,
                         "y is a really big number",
                         "y isn't that big")))
    
########################################################
## Loops
########################################################
# We use loops when we want to repeat a particular
# operation over and over again.
    
# There are lots of different types of loops you can
# use in R. This section will cover the for loop, one
# of the most common/useful loops you'll see is a for loop
    
# The general structure of a for loop is this:
    
    # for(i in 1:100){
      # your arguments
    #}
        
    # Here, i is just a variable you'll use to index
    # your iterations. It tells you which step of the
    # loop you're on. That means that i is necessarily
    # an integer.
    
    # Note that you don't have to use i. You can
    # indicate your index with any variable name.
    
    # Note also that you needn't use 1:100 or 1: some
    # value to tell R how many iterations you need.
    # You can use the sequence command, e.g. 
    # for(i in seq(1, 100, 1)){....}, or you can
    # use the number of rows in your data or observations
    # in your vector, e.g. for(i in 1:nrow(data)){...} or
    # for(i in 1:length(vector)){...}
    
    ## To understand loops in any programming language, you first
    ## need to understand indexing in a loop
    
    ## Take this very simple loop:
    ## In this case, the loop is indexed by 'i'.
    ## The loop starts with i = 1, goes through all the lines of the loop
    ## then returns to the top of the loop and sets i = 2. The loop knows to
    ## stop when it reaches i = 10
    
    for(i in 1:10){
      
      print(i)
      
    }
    
    ## That loop's indexing is identical to this one:
    
    for(i in seq(1,10)){
      
      print(i)
      
    }
    
    ## And this one:
    
    index <- 1:10
    
    for(i in index){
      
      print(i)
      
    }
    
    ## Your indexes don't need to be sequential
    # This one prints all even numbers between 2 and 50
    
    for(i in seq(2,50,2)){
      
      print(i)
    }
    
    ## Side note: "print()" statements are an incredibly useful
    ## thing to put into code. They'll help you debug your code by letting
    ## you know where your code hit snags. Or if you're looping over a huge number
    ## of things that take a really long time, they'll tell you where to restart
    ## your loop if you turn off your computer
    
    ## Your loop doesn't even need to be indexed by numbers:
    index <- c("look", "how", "fancy", "we", "can",
               "be", "with", "loop", "indexes")
    
    for(i in index){
      
      print(i)
      
    }
    
    
    ## Another note about indexing and loops:
    ## If you put loops within loops, be careful that you never use the 
    ## the same letter to index two different loops.
    
    ## In other words, don't do this:
    
    for(i in 1:10){
      
      for(i in 50:60){
        
        ## Some sort of code...
      }
      
    }
    
    ## Don't this won't necessarily prevent your code from working,
    ## but it could cause you a headache that can be frustrating to 
    ## try to diagnose. 
    
    ## Instead your loops should look something like this:
    
    for(i in 1:10){
      
      for(j in 50:60){
        
        ## some sort of code...
      }
      
    }
    
########################################################
## Data Frames and Loading Data
########################################################

## Like matrices, data frames are two dimensional r x c
## objects. UNLIKE matrices, however, data frames
## can consist of vectors in multiple data types.
      
  ## e.g., you can have one column of character data
  ## such as names, one column of numeric data such
  ## as height of each person in cm., etc.
    
## Loading Data
########################################################
## The first step is to set your working directory
    
    setwd("~/Dropbox/Teaching/Course Folders/Gov 2001/Gov2001 2014/Spring2016/Sections/Section 0 R Intro/")
    
## The next step is to load your data.
## R has several different functions that load different
## types of data. 
    
## Let's load the houses.tab file in today's section 
## data using the read.table() function
  
  houses_data <- read.table(file = "houses.txt", 
                            header = T, sep = "\t")

## The general syntax for loading data is
## data.frame.name <- 
## read.datatype(file = "filename.in.quotes.fxt", 
## option1 = ...)
  
## In the command above, header = T is an option
## that tells R whether your data has a header row
## with variable names (T), and sep = is an option
## that tells R what kind of character separates
## the columns from one another. In this case it's
## a tab, indicated by "\t". But it could be a comma
## ",", or a space " ", or many other possible
## separators.
  
## NOTICE THAT WE ARE ASSIGNING THE DATA TO SOME
## OBJECT NAME. THIS IS HOW R KNOWS TO STORE THE 
## DATA IT READS FROM YOUR FILE IN MEMORY.
  
## Working with data frames
########################################################
  
## R's read.table() loads your data as a data frame 
## object.
  
## Here are some things you can do to examine and subset
## your data frame object:
  
  ## Use the head() function to see the first few
  ## rows and columns of your data frame:
  
    head(houses_data)
    
  ## You can look at the columns by name using the 
  ## $ operator 
    
    houses_data$PRICE 
  
    ## This extracts the PRICE column as a vector
    
  ## Or using the colname in brackets
  
    houses_data["PRICE"]
    
  ## To get the names of the data frame, use the 
  ## names() function
    
    names(houses_data)
    
  ## Alternatively, you can treat it like a matrix
    
    houses_data[,1]
    
  ## You can use boolean expressions to select 
  ## subsets of vectors
    
    houses_data[houses_data$SQFT > 2000,]
    
    ## This selects the prices of all houses that 
    ## have square footage greater than 2000
    
    ## The boolean statement goes before the comma
    ## because your condition is applied to rows,
    ## or observations, that are greater than 2000
    ## in a particular column
    
    ########################################
    ## Loop example
    
    ## Let's take another look at our housing data.
    ## Suppose I wanted to take 10,000 random samples
    ## of 100 homes from within my housing data 
    ## and calculate an average price per square foot
    ## from each sample.
    
    ## I could do this with a loop!
    
    ## First, I'd want to create an object to store
    ## the 10,000 average price/sq. ft. values
    ## I'm going to be calculating, so I would
    ## do this:
    
    sq.ft.price <- NULL # creates an empty object
    
    for(i in 1:10000){
      sample.data <- houses_data[sample(1:nrow(houses_data), 100),]
      # the sample command draws a random sample from a given sample space.
      # The arguments it takes are: sample(x = a vector of numbers to sample from, 
      # n = sample size, replace = logical T/F that specifies whether you sample with replacement)
      # Note that this just generates a list of numbers. To actually get those rows of my data
      # I need to subset my data object for those rows!
      price.persqft <- sample.data$PRICE / sample.data$SQFT # I'll create a price per sq. ft. variable
      sq.ft.price[i] <- mean(price.persqft) # then I set the ith element of my storage vector to my result
    }
    
########################################################
## Basic Plotting
########################################################
    
## Histograms
########################################################
  ## R's hist() function plots histograms:
    
    hist(c(1,1,2,2,3,3,3,3), 
         main = "My Plot", 
         xlab = "My variable") 
    
    ## The general syntax for histograms in R is 
    ## hist(data, main = "Title in Quotes", xlab = "x
    ## axis label in quotes", breaks = vector of 
    ## custom breaks between the bars if you want those)
    
    
## Scatter plots
  ## R's plot() function plots scatterplots:
    
  plot(x = c(1,2,3,4,5), ## Data for x variable
       y = c(4,2,0,1,4), ## Data for y variable
       pch = 18, ## Type of point to plot (http://www.endmemo.com/program/R/pchsymbols.php)
       col = "Red", ## Can be a vector too! So can pch
       main = "My Plot", ## Plot title
       xlab = "X Variable", ## x axis label
       ylab = "Y Variable") ## y axis label

# Exporting your plots    
########################################################
  ## Use the pdf() and dev.off() commands to 
  ## export your plot to a .pdf:
    
    pdf("plot_output.pdf") # Begin with this statement
  
  ## This command tells R to output any graphics to a pdf file
  
    plot(x = c(1,2,3,4,5), ## Data for x variable
         y = c(4,2,0,1,4), ## Data for y variable
         pch = 18, ## Type of point to plot (http://www.endmemo.com/program/R/pchsymbols.php)
         col = "Red", ## Can be a vector too! So can pch
         main = "My Plot", ## Plot title
         xlab = "X Variable", ## x axis label
         ylab = "Y Variable") ## y axis label
    
    ## Put all of your plot code after your pdf() 
    ## statement
    
  ## End your export argument using dev.off() or
  ## graphics.off(), otherwise R will just keep
  ## adding your lines of code to the .pdf file 
  ## and the plot won't render.
    
      dev.off()
    