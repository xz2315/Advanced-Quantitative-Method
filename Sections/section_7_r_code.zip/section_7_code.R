### Section 7 - R Examples

##### Modelling Nested Data

#### Set working directory
setwd("~/Dropbox/Gov2001 2014/Spring2016/Sections/Section 7")

#####################################################
#### Zero-inflated Models
#####################################################

fish <- read.table("http://www.ats.ucla.edu/stat/data/fish.csv", sep=",", header=T)

# Our covariates on whether or not you catch a fish given that you are fishing are
# whether or not you have a child and how many people in your group
X <- fish[c("child", "persons")]
# Our covariates on whether or not you fish is just how many people in your group
Z <- fish[c("persons")]
# Add intercepts
X <- as.matrix(cbind(1,X))
Z <- as.matrix(cbind(1,Z))
Y <- fish$count
mean(fish$count)
### Plot distribution of fish caught
pdf("empirical_fish.pdf")
hist(Y, xlab="Number of fish caught", ylab="Number of Respondents", main="Empirical distribution of # of fish caught", breaks=100)
dev.off()

pdf("empirical_fish_narrow.pdf")
hist(Y, xlim=c(0, 15), xlab="Number of fish caught", ylab="Number of Respondents", main="Empirical distribution of # of fish caught", breaks=600)
dev.off()


# Write a function for the log-likelihood
ll.zipoisson <- function(par, X, Z, Y){
  beta <- par[1:ncol(X)]
  gamma <- par[(ncol(X)+1):length(par)]
  
  ## Which indices are Y = 0?
  yzero <- Y==0 #
  ynonzero <- Y > 0
  
  ## First part of likelihood
  lik <- -sum(log(1 + exp(Z%*%gamma))) + # Sum over all N
    sum(log(exp(Z[yzero,]%*%gamma) + exp(-exp(X[yzero,]%*%beta)))) +
    sum(Y[ynonzero]*X[ynonzero,]%*%beta - exp(X[ynonzero,]%*%beta))
 
  return(lik)

}


# Then we can optimize our likelihood function
par <- rep(1,(ncol(X)+ncol(Z)))
out <- optim(par, ll.zipoisson, Z=Z, X=X,Y=Y, method="BFGS", 
             control=list(fnscale=-1), hessian=TRUE)

out$par

# Check against the zinf package in pscl
require(pscl)
zeroinflated <- zeroinfl(count ~ child + persons | persons, data = fish)
summary(zeroinflated)

# These coefficients don't mean much, so we want to simulate
# to get the predicted probability of Not Fishing
varcv.par <- solve(-out$hessian)
library(mvtnorm)
# Simulate our gammas and our betas
sim.pars <- rmvnorm(10000, out$par, varcv.par)
# Subset to only the parameters we need (gammas)
# Better to simulate all though
sim.z <- sim.pars[,(ncol(X)+1):length(par)]


# Calculate the predicted probabilities for four different group sizes
person.vec <- seq(1,4)
# Each row is a different vector of covariates (our setx)
Zcovariates <- cbind(1, person.vec)
# Calculate predicted probability (inverse logit) for each set of covariates
# Remember that for each group size, this is a vector of 10000 predicted probabilities
exp.holder <- matrix(NA, ncol=4, nrow=10000)
for(i in 1:length(person.vec)){
  exp.holder[,i] <- exp(Zcovariates[i,]%*%t(sim.z))/(1+exp(Zcovariates[i,]%*%t(sim.z)))
}

# Let's plot the distribution for each group size
pdf("struct_zero.pdf")
plot(density(exp.holder[,4]), col="blue", xlim=c(0,1), ylim=c(0,10) ,
     main="Probability of a Structural Zero", xlab="Probability", lwd=3)
lines(density(exp.holder[,3]), col="red", lwd=3)
lines(density(exp.holder[,2]), col="green", lwd=3)
lines(density(exp.holder[,1]), col="black", lwd=3)
legend("topright", legend=c("One Person", "Two People", 
                       "Three People", "Four People"), 
       col=c("black", "green", "red", "blue"), lty=1, lwd=3)

dev.off()
# Let's plot the count distribution conditional on $Z_i = 1$
# Subset our simulation to simulated Xs
sim.x <- sim.pars[,1:ncol(X)]

# Calculate distribution of fish caught | fishing
# Set covariates to median # of children and median # of people
Xcovariates <- apply(X, 2, median)
# Remember that for each group size, this is a vector of 10000 predicted probabilities
set.seed(02138)
fish <- rep(NA, nrow=10000)
fish <- rpois(10000,exp(Xcovariates%*%t(sim.x)))

# Let's plot the distribution for the median group
pdf("fish_conditional.pdf")
hist(fish, xlim=c(0,15),
     main="Distribution of number of fish Caught by a 2 Person, 0 Child group\ngiven that they fished", 
     xlab="Number of Fish", freq=F, breaks=100)
dev.off()


######################################################
#### Fixed and Random Effects Models
######################################################

#### Libraries
require(lme4)

#### Load data
data.2012 <- read.csv("obama_2012_data.csv")

#### Make vote share variable
data.2012$obama.share <- data.2012$obama.votes/data.2012$total.votes

#### Log median income
data.2012$log.median.income <- log(data.2012$median.income)

#### A simple regression
simple.reg <- lm(obama.share ~ log.median.income, data= data.2012)
summary(simple.reg)

pdf("model1_regularlinearmodel.pdf")
#### Plot the simple regression
plot(y=data.2012$obama.share, x=data.2012$log.median.income, pch=18, col="grey75", xlab="Log Median Income - 2012", ylab="2012 Obama Vote Share",main="County-level relationship between 2012 Obama\nvote share and median income")
abline(simple.reg, lwd=4, col="Blue")
dev.off()


#### Fixed effects regression
fe.reg <- lm(obama.share ~ log.median.income + state, data=data.2012)
summary(fe.reg)

#### Plot lines for four states for the FE regs
### Georgia
pdf("model2_georgia.pdf")
plot(y=data.2012$obama.share, x=data.2012$log.median.income, pch=18, col="grey90", xlab="Log Median Income - 2012", ylab="2012 Obama Vote Share",main="Georgia highlighted")
points(y=data.2012$obama.share[data.2012$state == "GA"], x=data.2012$log.median.income[data.2012$state == "GA"], pch=18, col="blue")
## Add the line
abline(a=coef(fe.reg)["(Intercept)"] + coef(fe.reg)["stateGA"], b=coef(fe.reg)["log.median.income"], lwd=4, col="Blue")
dev.off()

### New York
pdf("model2_newyork.pdf")
plot(y=data.2012$obama.share, x=data.2012$log.median.income, pch=18, col="grey90", xlab="Log Median Income - 2012", ylab="2012 Obama Vote Share",main="New York Highlighted")
points(y=data.2012$obama.share[data.2012$state == "NY"], x=data.2012$log.median.income[data.2012$state == "NY"], pch=18, col="blue")
## Add the line
abline(a=coef(fe.reg)["(Intercept)"] + coef(fe.reg)["stateNY"], b=coef(fe.reg)["log.median.income"], lwd=4, col="Blue")
dev.off()

### California
pdf("model2_california.pdf")
plot(y=data.2012$obama.share, x=data.2012$log.median.income, pch=18, col="grey90", xlab="Log Median Income - 2012", ylab="2012 Obama Vote Share",main="California Highlighted")
points(y=data.2012$obama.share[data.2012$state == "CA"], x=data.2012$log.median.income[data.2012$state == "CA"], pch=18, col="blue")
abline(a=coef(fe.reg)["(Intercept)"] + coef(fe.reg)["stateCA"], b=coef(fe.reg)["log.median.income"], lwd=4, col="Blue")
dev.off()

### Alabama
pdf("model2_alabama.pdf")
plot(y=data.2012$obama.share, x=data.2012$log.median.income, pch=18, col="grey90", xlab="Log Median Income - 2012", ylab="2012 Obama Vote Share",main="Alabama Highlighted")
points(y=data.2012$obama.share[data.2012$state == "AL"], x=data.2012$log.median.income[data.2012$state == "AL"], pch=18, col="blue")
abline(a=coef(fe.reg)["(Intercept)"], b=coef(fe.reg)["log.median.income"], lwd=4, col="Blue") ### Alabama is the baseline category, so it's just the intercept
dev.off()

#### Mixed effects models - random intercept
mixed.eff <- lmer(obama.share ~ log.median.income + (1 | state), data=data.2012)
summary(mixed.eff)

#### Get the fixed effects
fixef(mixed.eff)

#### Get the estimated random effects
ranef(mixed.eff)

#### Plot Random Effects
pdf("model3_california.pdf")
plot(y=data.2012$obama.share, x=data.2012$log.median.income, pch=18, col="grey90", xlab="Log Median Income - 2012", ylab="2012 Obama Vote Share",main="California Highlighted\nRandom Effects, Varying intercept")
points(y=data.2012$obama.share[data.2012$state == "CA"], x=data.2012$log.median.income[data.2012$state == "CA"], pch=18, col="blue")
abline(a=fixef(mixed.eff)["(Intercept)"] + ranef(mixed.eff)$state["CA",1], b=fixef(mixed.eff)["log.median.income"], lwd=4, col="Blue")
abline(a=coef(fe.reg)["(Intercept)"] + coef(fe.reg)["stateCA"], b=coef(fe.reg)["log.median.income"], lwd=4, col="red")
dev.off()

pdf("model3_alabama.pdf")
plot(y=data.2012$obama.share, x=data.2012$log.median.income, pch=18, col="grey90", xlab="Log Median Income - 2012", ylab="2012 Obama Vote Share",main="Alabama Highlighted\nRandom Effects, Varying intercept")
points(y=data.2012$obama.share[data.2012$state == "AL"], x=data.2012$log.median.income[data.2012$state == "AL"], pch=18, col="blue")
abline(a=coef(fe.reg)["(Intercept)"], b=coef(fe.reg)["log.median.income"], lwd=4, col="Blue")
abline(a=fixef(mixed.eff)["(Intercept)"] + ranef(mixed.eff)$state["AL",1], b=fixef(mixed.eff)["log.median.income"], lwd=4, col="red")
legend("topleft", legend=c("Random Effects", "Fixed Effects"), 
       col=c("red", "blue"), lty=1, lwd=3)
dev.off()


#### Mixed Effects slope and intercept

### fully interactive model
#### Fixed effects regression
fe.reg.interact <- lm(obama.share ~ log.median.income + state + log.median.income*state, data=data.2012)
summary(fe.reg.interact)

## Confirm equivalent to just subsetting
summary(lm(obama.share~ log.median.income, data=subset(data.2012, state=="AL")))


#### Plot Both models
pdf("model6_california.pdf")
plot(y=data.2012$obama.share, x=data.2012$log.median.income, pch=18, col="grey90", xlab="Log Median Income - 2012", ylab="2012 Obama Vote Share",main="California Highlighted\nFixed effects, varying slope/intercept")
points(y=data.2012$obama.share[data.2012$state == "CA"], x=data.2012$log.median.income[data.2012$state == "CA"], pch=18, col="blue")
abline(a=coef(fe.reg.interact)["(Intercept)"] + coef(fe.reg.interact)["stateCA"], b=coef(fe.reg.interact)["log.median.income"] + coef(fe.reg.interact)["log.median.income:stateCA"], lwd=4, col="Blue")
abline(a=fixef(mixed.eff.interact)["(Intercept)"] + ranef(mixed.eff.interact)$state["CA",1], b=fixef(mixed.eff.interact)["log.median.income"] + ranef(mixed.eff.interact)$state["CA",2], lwd=4, col="Red")
legend("topleft", legend=c("Random Effects", "Fixed Effects"), 
       col=c("red", "blue"), lty=1, lwd=3)
dev.off()

pdf("model6_alabama.pdf")
plot(y=data.2012$obama.share, x=data.2012$log.median.income, pch=18, col="grey90", xlab="Log Median Income - 2012", ylab="2012 Obama Vote Share",main="Alabama Highlighted\nFixed effects, varying slope/intercept")
points(y=data.2012$obama.share[data.2012$state == "AL"], x=data.2012$log.median.income[data.2012$state == "AL"], pch=18, col="blue")
abline(a=coef(fe.reg.interact)["(Intercept)"], b=coef(fe.reg.interact)["log.median.income"], lwd=4, col="Blue") ### Alabama is the baseline category, so it's just the intercept
abline(a=fixef(mixed.eff.interact)["(Intercept)"] + ranef(mixed.eff.interact)$state["AL",1], b=fixef(mixed.eff.interact)["log.median.income"] + ranef(mixed.eff.interact)$state["AL",2], lwd=4, col="Red")
legend("topleft", legend=c("Random Effects", "Fixed Effects"), 
       col=c("red", "blue"), lty=1, lwd=3)
dev.off()


